import axios from "axios";
import React, { useEffect, useState } from "react";
import {
  Button,
  Card,
  InputGroup,
  Table,
  ToastContainer,
} from "react-bootstrap";
import { Link, useParams } from "react-router-dom";
import { toast } from "react-toastify";
import Navbar from "../Navbar/Navbar";

const Home = () => {
  const params = useParams();
  const token = localStorage.getItem("token");
  const [student, setStudent] = useState([]);
  const getInitialState = () => {
    const value = "please select the year";
    return value;
  };

  const [value, setValue] = useState(getInitialState);

  const handleChange = (e) => {
    setValue(e.target.value);
  };
  const fetchStudent = () => {
    axios
      .get(`http://3.110.131.173:4000/api/v1/year`, {
        headers: { Authorization: `Bearer ${token}` },
      })
      .then((response) => {
        setStudent(response.data.data);
        console.log(response.data);
      });
  };
  useEffect(() => {
    fetchStudent();
  }, []);
  console.log(student);
  return (
    <div>
      <Navbar></Navbar>
      <div className="container">
        <Card style={{ width: "200", marginTop: "4%" }}>
          <Card.Header>List of students</Card.Header>
          <Card.Body>
            <select value={value} onChange={handleChange}>
              <option value="2016-2017">2016-2017</option>
              <option value="2017-2018">2017-2018</option>
              <option value="2018-2019">2018-2019</option>
              <option value="2019-2020">2019-2020</option>
              <option value="2020-2021">2020-2021</option>
              <option value="2021-2022">2021-2022</option>
              <option value="2023-2024">2023-2024</option>
              <option value="2024-2025">2024-2025</option>
              <option value="2025-2026">2025-2026</option>
              <option value="2026-2027">2026-2027</option>
              <option value="2027-2028">2027-2028</option>
              <option value="2028-2029">2028-2029</option>
              <option value="2029-2030">2029-2030</option>
              <option value="2030-2031">2030-2031</option>
              <option value="2031-2032">2031-2032</option>
              <option value="2032-2033">2032-2033</option>
              <option value="2033-2034">2033-2034</option>
              <option value="2034-2035">2034-2035</option>
              <option value="2036-2037">2036-2037</option>
              <option value="2038-2039">2038-2039</option>
              <option value="2040-2041">2040-2041</option>
              <option value="2042-2043">2042-2043</option>
              <option value="2044-2045">2044-2045</option>
              <option value="2045-2046">2045-2046</option>
              <option value="2046-2047">2046-2047</option>
              <option value="2047-2048">2047-2048</option>
              <option value="2049-2050">2049-2050</option>
              <option value="2050-2051">2050-2051</option>
              <option value="2051-2052">2051-2052</option>
              <option value="2052-2053">2052-2053</option>
              <option value="2053-2054">2053-2054</option>
              <option value="2054-2055">2054-2055</option>
              <option value="2055-2056">2055-2056</option>
            </select>
            <p>{`You selected ${value}`}</p>

            <Link to="/Create">
              <Button variant="primary">add</Button>
            </Link>

            <Table striped bordered hover style={{ marginTop: "2%" }}>
              <thead>
                <tr>
                  <th scope="col">No</th>
                  <th scope="col">Student Name</th>
                  <th scope="col">DOB</th>
                  <th scope="col">Gender</th>
                  <th scopa="col">Email</th>
                  <th scope="col">Admission Date</th>
                  <th scope="col">Address</th>
                  <th scope="col">Phone Number</th>
                  <th scope="col">Admission No</th>
                  <th scope="col">Year Id</th>
                  <th scope="col">Student Type</th>
                </tr>
              </thead>

              <tbody>
                <tr>
                  <th scope="row"></th>
                  <td>{student.student_name}</td>
                  <td>{student.DOB}</td>
                  <td>{student.gender}</td>
                  <td>{student.email}</td>
                  <td>{student.admission_date}</td>
                  <td>{student.address}</td>
                  <td>{student.phone_number}</td>
                  <td>{student.admission_no}</td>
                  <td>{student.year_id}</td>
                  <td>{student.student_type}</td>
                </tr>
              </tbody>
            </Table>
          </Card.Body>
        </Card>
      </div>
    </div>
  );
};

export default Home;
