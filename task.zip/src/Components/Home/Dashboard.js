import React from "react";
import Navbar from "../Navbar/Navbar";

const Dashboard = () => {
  return (
    <div>
      <Navbar></Navbar>
      Welcome
    </div>
  );
};

export default Dashboard;
